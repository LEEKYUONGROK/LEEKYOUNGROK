#include "GameManager.h"


GameManager::GameManager()
{
	string input_string = "";
	m_iStage = 1;
	m_iGame_Speed = 700;
}

bool GameManager::Menu()
{
	int Select;
	system("cls");
	m_Odraw.Mid_print("����ġ�� ����", HIEGHT * 0.1);
	m_Odraw.Mid_print("1.����", HIEGHT * 0.2);
	m_Odraw.Mid_print("2.�÷��̾� ��ŷ", HIEGHT * 0.3);
	m_Odraw.Mid_print("3.����", HIEGHT * 0.4);
	m_Odraw.Mid_print("�Է� : ", HIEGHT * 0.5);
	cin >> Select;
	switch (Select)
	{
	case 1:
		m_iStage = 1;
		Play();
		return true;
	case 2:
		m_Oplayer.Print_Player_Rank();
		return true;
	case 3:
		return false;
	}
}
void GameManager::Play()
{
	int Position_Over_Word;
	char ch;
	m_Oplayer.Set_Player();
	Move_Clock = clock();
	Produce_Clock = clock();
	
	while (m_iStage <= 5)
	{
		system("cls");
		int Stage_UP_Point = 0, Confirm_Color;
		Word m_Oword;
		m_Oword.Set_List(m_iStage);
		m_Oword.Set_Head();
		while (m_Oplayer.Return_NowLife() && Stage_UP_Point <= 1000)//1000�� ������ ���� ���������� >>
		{
			Position_Over_Word = 0;
			CurClock = clock();
			if (kbhit())
			{
				ch = getch();
				if (ch == 13)
				{
					Confirm_Color = m_Oword.Input_Word(input_string);
					if (Confirm_Color < COL_END)
					{
						m_Oplayer.Point_UP();
						m_Oword.Delete_Null_Adress();
						m_Oword.If_Next_Adress_Null();
						Stage_UP_Point += 100;
						if (Confirm_Color == COL_BLUE)
							m_iGame_Speed += 100;
						else if (Confirm_Color == COL_RED)
							m_Oplayer.Player_LifeUP();
					}
					else if (Confirm_Color == COL_YELLOW)
					{
						m_Oword.All_Delete();
						m_Oword.Set_Head();
						m_Oplayer.Point_UP();
						Stage_UP_Point += 100;
					}
					else
						m_Oplayer.Life_Down();
					input_string = "";
				}
				else if (ch == 8 && (input_string.length() != 0))
					input_string = input_Back(input_string);
				else if (ch == 27)//ESC
					return;
				else
					input_string += ch;
				m_Odraw.Mid_print(input_string, 30);
			}
			if (CurClock - Move_Clock >= m_iGame_Speed)
			{
				system("cls");
				m_Oword.Move_Word();//�ܾ y������ �����̰� 
				Position_Over_Word = m_Oword.Over_PositionCheck();
				for (int i = 0; i < Position_Over_Word; i++)//������ �ܾ� ���̸� üũ�ϰ� ������--
					m_Oplayer.Life_Down();
				m_Oword.Delete_Null_Adress();//�ʱ�ȭ�� �ܾ �Ҵ������� �Ҵ� 
											 //Null_Adress�Ҵ� ������ ��ũ �����ּҸ� �־���
				m_Oword.If_Next_Adress_Null();//������ �ּҰ� null�̸� �̾��ģ��

				m_Oword.Print_List();
				m_Oplayer.Print_Inpomatoin();
				m_Odraw.BoxDraw(20, 5);
				m_Odraw.Mid_print(input_string, 30);
				Move_Clock = CurClock;  
			}
			if (CurClock - Produce_Clock >= 2000)
			{
				m_Oword.Set_NewWord();
				Produce_Clock = CurClock;
			}
		}
		if (m_Oplayer.Player_GameOver() == true)
			return;
		else
		{
			m_Odraw.Mid_print("�������� ��", 15);
			cout << endl;
			system("pause");
			m_iStage++;
		}
	}
}
string GameManager::input_Back(string text)
{
	string tmp = "";
	int text_length = text.length();

	for (int i = 0; i < text_length - 1; i++)
		tmp += text[i];
	return tmp;
}
GameManager::~GameManager()
{
}
