#pragma once
#include "DrawManager.h"
#include <fstream>
#include <time.h>
#include <conio.h>
#define LIST_MAX 10


struct  Word_inpomation
{
	string Sword;
	int Position_X, Position_Y, Color;
	Word_inpomation* Next;
};

class Word
{
private:
	string* Word_List;
	Word_inpomation* Head = NULL, *tmp, *add_Word, *Null_Adress;
	int List_Counter, m_iWhile_Counter;
	DrawManager Draw;
public:
	void All_Delete();
	void Set_Color(Word_inpomation* Word_inpo);
	void Delete_List(Word_inpomation* Node);
	void Erage_Word();
	int Input_Word(string st);
	void If_Next_Adress_Null();
	void Delete_Null_Adress();
	void Move_Word();
	int Over_PositionCheck();
	void Print_List();
	void Set_List(int Level);
	void Set_Head();
	void Set_NewWord();
	Word();
	~Word();
};