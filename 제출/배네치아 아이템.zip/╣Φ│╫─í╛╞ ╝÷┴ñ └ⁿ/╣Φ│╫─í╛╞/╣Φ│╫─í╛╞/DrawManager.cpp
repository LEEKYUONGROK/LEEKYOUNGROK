#include "DrawManager.h"



DrawManager::DrawManager()
{
}

void DrawManager::BoxDraw(int x,int y)
{
	for (int j = 0; j < y; j++)
	{
		for (int i = 0; i < x; i += 2)
		{
			gotoxy((WIDTH / 2 - x / 2) + i, HIEGHT + j);
			if (j == 0 && i == 0)
				cout << "��";
			else if (j == 0 && i == x - 2)
				cout << "��";
			else if (j == y - 1 && i == 0)
				cout << "��";
			else if (j == y - 1 && i == x - 2)
				cout << "��";
			else if ((j == 0 || j == y - 1) && (i > 0 || i < x - 2))
				cout << "��";
			else if ((j > 0 || j < y - 1) && (i == 0 || i == x - 2))
				cout << "��";
			else
				cout << " ";
		}
		cout << endl;
	}
}
void DrawManager::Draw_String(string str,int x,int y,int color)
{
	gotoxy(x, y);
	if (color == COL_RED)
		RED
	else if (color == COL_BLUE)
		BLUE
	else if (color == COL_YELLOW)
		YELLOW
	cout << str;
	ORIGINAL
}
void DrawManager::Mid_print(string str,int y)
{
	gotoxy(WIDTH / 2 - str.length() / 2, y);
	cout << str;
}
void DrawManager::Print_PointLife(int Point,int Life)
{
	gotoxy(WIDTH * 0.7,HIEGHT);
	cout << "Point : " << Point;
	gotoxy(WIDTH * 0.7, HIEGHT + 1);
	cout << "LIFE : " << Life;
}
DrawManager::~DrawManager()
{
}