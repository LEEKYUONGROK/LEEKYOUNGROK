#pragma once
#include "Word.h"

class GameManager
{
private:
int Move_Clock, Produce_Clock, CurClock,Select, m_iPoint,m_iPlayerLife;
string input_string;
DrawManager m_Odraw;
Word m_Oword;

public:
	string input_Back(string text);
	bool Menu();
	void Play();
	void Select_Level();
	GameManager();
	~GameManager();
};

