#include "GameManager.h"

void main()
{
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", HIEGHT + 5, WIDTH);
	system(buf);

	while (1)
	{
		GameManager Game;
		if (false == Game.Menu())
				return;
	}
}