#pragma once
#include "DrawManager.h"
#define Player_Max 5
using namespace std;

struct Player_inpo
{
	int Point,m_iPlayerLife;
	string Name;
};

class Player_inpomation
{
private :
int Counter;
DrawManager Draw;
Player_inpo Player_List[Player_Max];
public:
	bool Player_GameOver();
	void Print_Player_Rank();
	void Print_Inpomatoin();
	bool Return_NowLife();
	void Life_Down();
	void Set_Player();
	void Point_UP();
	Player_inpomation();
	~Player_inpomation();
};

