#pragma once
#include <iostream>
#include <Windows.h>
#include <string>

#define HIEGHT 30
#define WIDTH 80
using namespace std;

class DrawManager
{
private:

public:
	void BoxDraw(int x,int y);
	void Draw_String(string st,int x, int y);
	void DrawString(string st,int x,int y);
	void Mid_print(string st,int y);
	void Print_PointLife(int Point,int Life);
	DrawManager();
	void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	~DrawManager();
};

