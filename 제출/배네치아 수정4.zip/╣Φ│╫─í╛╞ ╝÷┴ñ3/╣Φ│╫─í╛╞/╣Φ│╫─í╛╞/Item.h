#pragma once
#include "Word.h"

class Item : public Word
{
public:
	void Set_Head_Col();
	void Set_NewWord_AND_Col();
	void Yellow_Item();
	void Set_Color(Word_inpomation* Word_inpo);
	void Plum_Item();
	int Input_Word(string st);
	Item();
	~Item();
};

