#include "Item.h"

Item::Item()
{
}
int Item::Input_Word(string str)
{
	tmp = Head;
	if (tmp->Sword == "")
		tmp = tmp->Next;
	while (tmp != NULL)
	{
		if ((tmp->Sword == str) && (str != ""))
		{
			tmp->Sword = "";
			tmp->Position_X = 0;
			tmp->Position_Y = 0;
			return tmp->Color;
		}
		else
			tmp = tmp->Next;
	}
	return -1;
}
void Item::Set_Color(Word_inpomation* Word_inpo)
{
	Word_inpo->Color = (rand() % 10);
	if (Word_inpo->Color == 9)
		Word_inpo->Color = COL_YELLOW;
	else if (Word_inpo->Color == 8 || Word_inpo->Color == 7)
		Word_inpo->Color = COL_RED;
	else if (Word_inpo->Color == 6)
		Word_inpo->Color = COL_BLUE;
	else if (Word_inpo->Color == 5)
		Word_inpo->Color = COL_PLUM;
	else
		Word_inpo->Color = COL_NOMAL;
}
void Item::Set_NewWord_AND_Col()
{
	Set_NewWord();
	Set_Color(add_Word);
}
void Item::Set_Head_Col()
{
	Set_Color(Head);
}
void Item::Plum_Item()
{
	tmp = Head;
	if((Head->Sword == "")&&(tmp->Next != NULL))
		tmp = tmp->Next;
	while (tmp != NULL)
	{
		Draw.Draw_String("��", tmp->Position_X, tmp->Position_Y, tmp->Color);
		tmp = tmp->Next;
	}
}
void Item::Yellow_Item()
{
	Delete_List(Head);
	Set_Head();
	Set_Head_Col();
}

Item::~Item()
{
}
