#pragma once
#include <iostream>
#include <Windows.h>
#include <string>
//////////////////////////////////////////////////////
#define col GetStdHandle(STD_OUTPUT_HANDLE) 
#define GREEN SetConsoleTextAttribute( col,0x0002 );
#define BLUE SetConsoleTextAttribute( col,0x0009 );
#define RED SetConsoleTextAttribute( col,0x000c );
#define PLUM SetConsoleTextAttribute( col,0x000d );
#define YELLOW SetConsoleTextAttribute( col,0x000e );
#define ORIGINAL SetConsoleTextAttribute( col,0x0007 );
//////////////////////////////////////////////////////
#define HIEGHT 30
#define WIDTH 80
using namespace std;

enum COLOR
{
	COL_NOMAL = 1,
	COL_RED,
	COL_BLUE,
	COL_PLUM,
	COL_YELLOW,
	COL_END = COL_YELLOW
};

class DrawManager
{
private:

public:
	void BoxDraw(int x,int y);
	void Draw_String(string st,int x, int y,int color);
	void Mid_print(string st,int y);
	void Print_PointLife(int Point,int Life);
	DrawManager();
	void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	~DrawManager();
};

