#include "GameManager.h"


GameManager::GameManager()
{
	string input_string = "";
	m_iStage_UP_Point = 0;
	m_iStage = 1;
	m_iGame_Speed = 700;
	m_iPlum_ItmeTime = 0;
}
void GameManager::Print_Word(Word* word)
{
	if (m_iPlum_ItmeTime <= 0)
		word->Print_List();
	else
	{
		word->Plum_Item();
		m_iPlum_ItmeTime--;
	}
}
bool GameManager::Menu()
{
	int Select;
	system("cls");
	m_Odraw.Mid_print("����ġ�� ����", HIEGHT * 0.1);
	m_Odraw.Mid_print("1.����", HIEGHT * 0.2);
	m_Odraw.Mid_print("2.�÷��̾� ��ŷ", HIEGHT * 0.3);
	m_Odraw.Mid_print("3.����", HIEGHT * 0.4);
	m_Odraw.Mid_print("�Է� : ", HIEGHT * 0.5);
	cin >> Select;
	switch (Select)
	{
	case 1:
		m_iStage = 1;
		Play();
		return true;
	case 2:
		m_Oplayer.Print_Player_Rank();
		return true;
	case 3:
		return false;
	}
}
void GameManager::Check_Item(Word* Word_Chck_item)
{
	int Confirm_COL;
	Confirm_COL = Word_Chck_item->Input_Word(input_string);

	if (Confirm_COL == COL_BLUE)
		m_iGame_Speed += 100;
	else if (Confirm_COL == COL_RED)
		m_Oplayer.Player_LifeUP();
	else if (Confirm_COL == COL_YELLOW)
	{
		Word_Chck_item->Yellow_Item();
		return;
	}
	else if (Confirm_COL == COL_NOMAL)
	{
		m_Oplayer.Point_UP();
		m_iStage_UP_Point += 100;
	}
	else if (Confirm_COL == COL_PLUM)
		m_iPlum_ItmeTime = 5;
	else
	{
		m_Oplayer.Life_Down();
		return;
	}
	Word_Chck_item->Delete_Null_Adress();
	Word_Chck_item->If_Next_WordNull();
	//Word_Chck_item->If_Next_Adress_Null();
}
void GameManager::Play()
{
	int Position_Over_Word;
	char ch;
	m_Oplayer.Set_Player();
	Move_Clock = clock();
	Produce_Clock = clock();
	
	while (m_iStage <= 5)
	{
		system("cls");
		m_iStage_UP_Point = 0;
		Word* m_Pword;
		Item m_Oitem;
		m_Pword = &m_Oitem;
		m_Pword->Set_List(m_iStage);
		m_Pword->Set_Head();
		m_Pword->Set_Head_Col();
		while (m_Oplayer.Return_NowLife() && m_iStage_UP_Point <= 1000)//1000�� ������ ���� ���������� >>
		{
			Position_Over_Word = 0;
			CurClock = clock();
			if (kbhit())
			{
				ch = getch();
				if (ch == 13)
				{
					Check_Item(m_Pword);
					input_string = "";
				}
				else if (ch == 8 && (input_string.length() != 0))
					input_string = input_Back(input_string);
				else if (ch == 27)//ESC
					return;
				else
					input_string += ch;
				m_Odraw.Mid_print(input_string, 32);
			}
			if (CurClock - Move_Clock >= m_iGame_Speed)
			{
				system("cls");
				m_Pword->Move_Word();//�ܾ y������ �����̰� 
				Position_Over_Word = m_Pword->Over_PositionCheck();
				for (int i = 0; i < Position_Over_Word; i++)//������ �ܾ� ���̸� üũ�ϰ� ������--
				{
					m_Oplayer.Life_Down();
					m_Pword->Delete_Null_Adress();//�ʱ�ȭ�� �ܾ �Ҵ�������
												 //Null_Adress�Ҵ� ������ ��ũ �����ּҸ� �־���
					m_Pword->If_Next_WordNull();
				//	m_Pword->If_Next_Adress_Null();//������ �ּҰ� null�̸� �̾��ģ��
				}
				Print_Word(m_Pword);
				m_Oplayer.Print_Inpomatoin();
				m_Odraw.BoxDraw(20, 5);
				m_Odraw.Mid_print(input_string, 32);
				Move_Clock = CurClock;  
			}
			if (CurClock - Produce_Clock >= 2000)
			{
				m_Pword->Set_NewWord_AND_Col();
				Produce_Clock = CurClock;
			}
		}
		if (m_Oplayer.Player_GameOver() == true)
			return;
		else
		{
			m_Odraw.Mid_print("�������� ��", 15);
			cout << endl;
			system("pause");
			m_iStage++;
		}
	}
}
string GameManager::input_Back(string text)
{
	string tmp = "";
	int text_length = text.length();

	for (int i = 0; i < text_length - 1; i++)
		tmp += text[i];
	return tmp;
}
GameManager::~GameManager()
{
}
