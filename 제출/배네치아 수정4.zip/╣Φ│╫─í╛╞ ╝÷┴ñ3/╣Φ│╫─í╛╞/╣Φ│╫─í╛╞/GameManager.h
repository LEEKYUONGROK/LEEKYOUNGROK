#pragma once
#include "Item.h"

class GameManager
{
private:
	int Move_Clock, Produce_Clock, CurClock, m_iGame_Speed,m_iPlum_ItmeTime;
	int m_iStage_UP_Point, m_iStage;
string input_string;
DrawManager m_Odraw;
Player_inpomation m_Oplayer;

public:
	string input_Back(string text);
	void Check_Item(Word* Word_Check_item);
	bool Menu();
	void Play();
	void Print_Word(Word* word);
	GameManager();
	~GameManager();
};

