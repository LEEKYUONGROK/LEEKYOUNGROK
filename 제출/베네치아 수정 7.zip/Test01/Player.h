#pragma once
#include"DrawManager.h"
#define PLAYER_MAX 5

struct PLAYER
{
	string Name;
	int Point,Life;
};
class Player
{
private:
	DrawManager m_Odraw;
	int m_iPlayer_Counter, Stage_Max_Point;
	PLAYER m_Player_List[PLAYER_MAX];
public:
	bool Life_On();
	void Player_Count_Up();
	void Print_Ranking();
	void Print_inpomation();
	void Life_UP();
	void Point_Up();
	void Life_Down();
	void Set_Player();
	Player();
	~Player();
};

