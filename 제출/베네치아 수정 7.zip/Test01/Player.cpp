#include "Player.h"

Player::Player()
{
	m_iPlayer_Counter = 0;
	Stage_Max_Point = 1300;
}
bool Player::Life_On()
{
	if (m_Player_List[m_iPlayer_Counter].Life > 0)
		return true;
	else
		return false;
}
void Player::Player_Count_Up()
{
	if (m_iPlayer_Counter < 4)
		m_iPlayer_Counter++;
}
void Player::Set_Player()
{
	if (m_iPlayer_Counter < 5)
	{
		system("cls");
		m_Odraw.Mid_print("�÷��̾� �̸��� �Է����ּ��� : ", 15);
		cin >> m_Player_List[m_iPlayer_Counter].Name;
		m_Player_List[m_iPlayer_Counter].Point = 0;
		m_Player_List[m_iPlayer_Counter].Life = 5;
	}
}
void Player::Print_Ranking()
{
	PLAYER tmp;
	system("cls");
	if (m_iPlayer_Counter == 0)
		m_Odraw.Mid_print("�÷��̾ �����ϴ�.", 15);
	else
	{
		for (int i = 0; i < m_iPlayer_Counter; i++)
		{
			for (int j = 0; j < m_iPlayer_Counter; j++)
			{
				if (m_Player_List[j].Point < m_Player_List[i].Point)
				{
					tmp = m_Player_List[i];
					m_Player_List[i] = m_Player_List[j];
					m_Player_List[j] = tmp;
				}
			}
		}
		for (int i = 0; i < m_iPlayer_Counter; i++)
			m_Odraw.Mid_print(m_Player_List[i].Name, HIEGHT + i);
	}
	system("pause");
}
void Player::Point_Up()
{
	m_Player_List[m_iPlayer_Counter].Point += 100;
}
void Player::Life_Down()
{
	m_Player_List[m_iPlayer_Counter].Life--;
}
void Player::Life_UP()
{
	m_Player_List[m_iPlayer_Counter].Life++;
}
void Player::Print_inpomation()
{
	int Point = m_Player_List[m_iPlayer_Counter].Point;
	int Life = m_Player_List[m_iPlayer_Counter].Life;
	m_Odraw.Print_Player_Inpomation(Point, Life);
}
Player::~Player()
{
}
