#pragma once
#include"Word.h"
#include"Player.h"

class Item
{
private:
	DrawManager m_Odraw;
public:
	void Item_Nomal(Player& player);
	void Item_Blue();
	void Item_Red(Player& player);
	void Item_Plum(Word& word);
	int Item_Yellow(Word& word, Player& player);
	Item();
	~Item();
};

