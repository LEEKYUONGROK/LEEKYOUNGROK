#pragma once
#include "DrawManager.h"
#include <fstream>
#include <time.h>
#include <conio.h>
#define STAGE_WORD_MAX 30

struct Word_inpomation
{
	string word;
	int PositionX, PositionY, color;
};

class Word
{
private:
	friend class Item;
	int Load_Word_Num;
	DrawManager m_Odraw;
	string* Load_Word_List;
	Word_inpomation* List_Head,*tmp;
public:
	void Print_Word();
	void Move_Word();
	int Over_PositionY();

	void Load_File(int Level);
	void ReSet_Address(Word_inpomation* Reset_Address);
	void ReSet_List();
	void Set_Impomation();

	void Stage_Up(int Stage_Level);
	string Set_Word(int Max);
	int input_String(string str);
	int Set_Color();
	Word();
	~Word();
};

