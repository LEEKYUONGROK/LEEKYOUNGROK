#include"GameManager.h"

void main()
{
	GameManager Game;
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", HIEGHT + 10, WIDTH);
	system(buf);

	Game.Start_Menu();
}