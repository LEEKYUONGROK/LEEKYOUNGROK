#include "Word.h"


Word::Word()
{
	List_Head = new Word_inpomation[STAGE_WORD_MAX];
}

void Word::Load_File(int Level)
{
	string Load_File = "Level";
	Load_File += to_string(Level);
	Load_File += ".txt";

	ifstream load;
	load.open(Load_File);
	while (!load.eof())
	{
		load >> Load_Word_Num;
		Load_Word_List = new string[Load_Word_Num];
		for (int i = 0; Load_Word_Num > i; i++)
			load >> Load_Word_List[i];
	}
}
void Word::Stage_Up(int Stage_Level)
{
	delete[] Load_Word_List;
	tmp = NULL;
	Load_File(Stage_Level);
	ReSet_List();
}
void Word::ReSet_List()
{
	for (int i = 0; STAGE_WORD_MAX > i; i++)
	{
		List_Head[i].word = "";
		List_Head[i].PositionY = NULL;
		List_Head[i].PositionX = NULL;
		List_Head[i].color = NULL;
	}
}
void Word::Move_Word() 
{
	tmp = List_Head;
	for (int i = 0; i < STAGE_WORD_MAX; i++)
	{
		if (tmp->word != "")
		{
			tmp->PositionY++;
			tmp++;
		}
		else
			tmp++;
	}
}
void Word::Print_Word()
{
	tmp = List_Head;
	for (int i = 0; i < STAGE_WORD_MAX; i++)
	{
		if (tmp->word != "")
		{
			m_Odraw.Draw_String(tmp->word, tmp->PositionX, tmp->PositionY, tmp->color);
			tmp++;
		}
		else
			tmp++;
	}
}
void Word::ReSet_Address(Word_inpomation* Reset_Address)
{
	Reset_Address->word = "";
	Reset_Address->PositionY = NULL;
	Reset_Address->PositionX = NULL;
	Reset_Address->color = NULL;
}
int Word::input_String(string str)
{
	int Return_Color;
	Word_inpomation* Delete_Address = NULL;
	tmp = List_Head;
	
	for (int i = 0; i < STAGE_WORD_MAX; i++)
	{
		if (tmp->word == str)
		{
			if (Delete_Address == NULL)
				Delete_Address = tmp;
			else if(tmp->PositionY > Delete_Address->PositionY)
				Delete_Address = tmp;
			tmp++;
		}
		else
			tmp++;
	}
	if (Delete_Address == NULL)
		return -1;
	else
	{
		Return_Color = Delete_Address->color;
		ReSet_Address(Delete_Address);
		return Return_Color;
	}
}
void Word::Set_Impomation()
{
	tmp = List_Head;
	for (int i = 0; i < STAGE_WORD_MAX; i++)
	{
		if (tmp->word == "")
		{
			tmp->word = Load_Word_List[rand() % Load_Word_Num];
			tmp->PositionX = rand() % 72;
			tmp->PositionY = 0;
			tmp->color = Set_Color();
			return;
		}
		else
			tmp++;
	}
}
int Word::Over_PositionY()
{
	int Return_Counter = 0;
	tmp = List_Head;
	for (int i = 0; i < STAGE_WORD_MAX; i++)
	{
		if ((tmp->word != "") && (tmp->PositionY >= HIEGHT))
		{
			ReSet_Address(tmp);
			Return_Counter++;
			tmp++;
		}
		else
			tmp++;
	}
	return Return_Counter;
}
int Word::Set_Color()
{
	int Rand_num = (rand() % 100) + 1;
	if (Rand_num > 95)
		return COL_YELLOW;
	else if ((95 >= Rand_num) && (Rand_num > 80))
		return COL_BLUE;
	else if ((80 >= Rand_num) && (Rand_num > 70))
		return COL_RED;
	else if ((70 >= Rand_num) && (Rand_num > 60))
		return COL_PLUM;
	else
		return COL_NOMAL;
}
Word::~Word()
{
	delete[] List_Head;
	delete[] Load_Word_List;
}
