#include "Item.h"

Item::Item()
{
}

void Item::Item_Plum(Word& word)
{
	word.tmp = word.List_Head;
	for (int i = 0; i < STAGE_WORD_MAX; i++)
	{
		if (word.tmp->word != "")
		{
			m_Odraw.Draw_String("��", word.tmp->PositionX, word.tmp->PositionY, word.tmp->color);
			word.tmp++;
		}
		else
			word.tmp++;
	}
}
int Item::Item_Yellow(Word& word,Player& player)
{
	int Counter = 0;
	word.tmp = word.List_Head;
	for (int i = 0;  i < STAGE_WORD_MAX ; i++)
	{
		if(word.tmp->word != "")
			Counter++;
		word.tmp->word = "";
		word.tmp->PositionY = NULL;
		word.tmp->PositionX = NULL;
		word.tmp->color = NULL;
		word.tmp++;
	}
	return Counter;
}
void Item::Item_Nomal(Player& player)
{
	player.Point_Up();
}
void Item::Item_Red(Player& player)
{
	player.Life_UP();
	player.Point_Up();
}
Item::~Item()
{
}
