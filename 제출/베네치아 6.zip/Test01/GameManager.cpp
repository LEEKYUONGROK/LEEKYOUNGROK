#include "GameManager.h"



GameManager::GameManager()
{
	m_iPulum_time = 0;
}

void GameManager::Start_Menu()
{
	int select;
	while (1)
	{
		system("cls");
		m_Odraw.Mid_print("�ڡ١ں���ġ�ơڡ١�", HIEGHT * 0.1);
		m_Odraw.Mid_print("1. ���� ����", HIEGHT * 0.3);
		m_Odraw.Mid_print("2. ��ŷ Ȯ��", HIEGHT * 0.4);
		m_Odraw.Mid_print("3. ���� ����", HIEGHT * 0.5);
		m_Odraw.Mid_print("�Է� : ", HIEGHT * 0.6);
		cin >> select;

		switch (select)
		{
		case 1:
			Play();
			break;
		case 2:
			m_Oplayer.Print_Ranking();
			break;
		case 3:
			return;
		}
	}
}
void GameManager::Game_Set(int Level)
{
	srand(time(NULL));
	m_Oword.Load_File(Level);
	m_Oword.ReSet_List();
	m_Oword.Set_Impomation();
	m_iStage_Up_Point = 0;
	m_iGame_Speed = 800;
}
void GameManager::Item_Use(int Color)
{
	int Point_UP_Conter;
	if (Color == COL_NOMAL)
	{
		m_Oitem.Item_Nomal(m_Oplayer);
		m_iStage_Up_Point += 100;
	}
	else if (Color == COL_BLUE)
	{
		m_Oplayer.Point_Up();
		m_iGame_Speed += 100;
		m_iStage_Up_Point += 100;
	}
	else if (Color == COL_PLUM)
	{
		m_iPulum_time = 5;
		m_Oplayer.Point_Up();
		m_iStage_Up_Point += 100;
	}
	else if (Color == COL_RED)
	{
		m_Oitem.Item_Red(m_Oplayer);
		m_iStage_Up_Point += 100;
	}
	else if (Color == COL_YELLOW)
	{
		Point_UP_Conter = m_Oitem.Item_Yellow(m_Oword, m_Oplayer);
		for (int i = 0; i <= Point_UP_Conter; i++)
		{
			m_Oplayer.Point_Up();
			m_iStage_Up_Point += 100;
		}
	}
}
void GameManager::Word_Position_Ckeck()
{
	int num = m_Oword.Over_PositionY();
	if (num != 0)
	{
		for (int i = num; i > 0; i--)
			m_Oplayer.Life_Down();
	}
}
void GameManager::Back_Speace(string str)
{
	string tmp = "";
	int str_leng = str.length();
	if (str_leng <= 1)
	{
		input_string = "";
		return;
	}
	for (int i = 0; i < str_leng - 1; i++)
		tmp += str[i];
	input_string = tmp;
}
void GameManager::Input_Key(char key)
{
	int Col;
	if (key == 13)//ENTER
	{
		Col = m_Oword.input_String(input_string);
		if (Col == -1)
			m_Oplayer.Life_Down();
		else
			Item_Use(Col);
		input_string = "";
	}
	else if (key == 8)//BACK_Speace
		Back_Speace(input_string);
	else if (key == 27)//ESC
	{
		// ����
	}
	else
		input_string += key;
}
void GameManager::Play()
{
	int Level = 1;
	char key;
	m_Oplayer.Set_Player();//������ �ٽ� �����ϸ� ȣ��
	Game_Set(Level);//word��ü�� �迭���� �ʱ�ȭ ���ְ� �ٽ�ȣ��

	system("cls");
	m_iMove_Clock = clock();
	m_iCreate_Clock = clock();
	m_Oword.Print_Word();
	m_Odraw.Draw_Box(10, 4);
	m_Oplayer.Print_inpomation();

	while (m_Oplayer.Life_On())
	{
		m_iCul_Clock = clock();
		if (kbhit())
		{
			key = getch();
			Input_Key(key);
			m_Odraw.Mid_print(input_string, 32);
		}
		if (m_iCul_Clock - m_iMove_Clock > m_iGame_Speed)
		{
			system("cls");
			m_Oword.Move_Word();
			if (m_iPulum_time > 0)
			{
				m_Oitem.Item_Plum(m_Oword);
				m_iPulum_time--;
			}
			else
				m_Oword.Print_Word();
			Word_Position_Ckeck();
			m_Oplayer.Print_inpomation();
			m_Odraw.Draw_Box(10, 4);
			m_Odraw.Mid_print(input_string, 32);
			m_iMove_Clock = m_iCul_Clock;
		}
		if (m_iCul_Clock - m_iCreate_Clock > 3000)
		{
			m_Oword.Set_Impomation();
			m_iCreate_Clock = m_iCul_Clock;
		}
		if(m_iStage_Up_Point > 1300)
		{
			Level++;
			m_Oword.Stage_Up(Level);
			m_iStage_Up_Point = 0;
		}
	}
	m_Oplayer.Player_Count_Up();
}
GameManager::~GameManager()
{
}
