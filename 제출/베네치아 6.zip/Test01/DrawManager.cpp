#include "DrawManager.h"



DrawManager::DrawManager()
{
}

void DrawManager::Draw_Box(int x, int y)
{
	x = x * 2;
	for (int j = 0; j < y; j++)
	{
		for (int i = 0; i < x; i += 2)
		{
			gotoxy((WIDTH / 2 - x / 2) + i, (HIEGHT + j) + 1);
			if (j == 0 && i == 0)
				cout << "��";
			else if (j == 0 && i == x - 2)
				cout << "��";
			else if (j == y-1 && i == 0)
				cout << "��";
			else if (j == y - 1 && i == x - 2)
				cout << "��";
			else if ((j == 0 || j == y-1) && (i > 0 && i < x-2))
				cout << "��";
			else if ((j > 0 && j < y-1) && (i == 0 || i == x-2))
				cout << "��";
			else
				cout << " ";
		}
	}
}
void DrawManager::Draw_String(string str, int x, int y, int color)
{
	gotoxy(x, y);
	if (color == COL_RED)
		RED
	else if (color == COL_BLUE)
		BLUE
	else if (color == COL_YELLOW)
		YELLOW
	else if (color == COL_PLUM)
		PLUM
		cout << str;
	ORIGINAL
}
void DrawManager::Print_Player_Inpomation(int Point,int Life)
{
	gotoxy(WIDTH / 2 + 5,HIEGHT + 5);
	cout << "���� : " << Point;
	gotoxy(WIDTH / 2 + 5,HIEGHT + 6);
	cout << "���� : " << Life;
}
void DrawManager::Mid_print(string str, int y)
{
	gotoxy(WIDTH / 2 - str.length() / 2, y);
	cout << str;
}

DrawManager::~DrawManager()
{
}
