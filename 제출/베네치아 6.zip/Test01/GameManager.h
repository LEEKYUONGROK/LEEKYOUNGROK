#pragma once
#include"Item.h"
#include"Player.h"

class GameManager
{
private:
	int m_iCul_Clock, m_iMove_Clock,m_iCreate_Clock, m_iPulum_time,m_iStage_Up_Point,m_iGame_Speed;
	string input_string;
	DrawManager m_Odraw;
	Word m_Oword;
	Item m_Oitem;
	Player m_Oplayer;
public:
	void End_Game();
	void Start_Menu();
	void Back_Speace(string str);
	void Word_Position_Ckeck();
	void Game_Set(int Level);
	void Play();
	void Input_Key(char Key);
	void Item_Use(int Color);
	//template<>
	//int input_Data<int>(Word& object, int num);
	GameManager();
	~GameManager();
};

