#pragma once
#include <Windows.h>
using namespace std;

class Player
{
public:
	Player();
	~Player();
};

