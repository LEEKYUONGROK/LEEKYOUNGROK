#pragma once
#include "Word.h"
#include "Player_inpomation.h"

class GameManager
{
private:
	int Move_Clock, Produce_Clock, CurClock, m_iStage;
string input_string;
DrawManager m_Odraw;
Player_inpomation m_Oplayer;

public:
	string input_Back(string text);
	bool Menu();
	void Play();
	GameManager();
	~GameManager();
};

