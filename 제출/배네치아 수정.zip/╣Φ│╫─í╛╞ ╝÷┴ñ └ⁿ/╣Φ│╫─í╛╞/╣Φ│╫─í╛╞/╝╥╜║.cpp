#include "GameManager.h"

void main()
{
	GameManager Game;
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", HIEGHT + 5, WIDTH);
	system(buf);

	while (Game.Menu() == true);
	
}