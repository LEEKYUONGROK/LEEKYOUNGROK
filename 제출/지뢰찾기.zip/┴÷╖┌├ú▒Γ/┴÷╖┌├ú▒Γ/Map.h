#pragma once
#include "DrawManager.h"
#define SEARCH_LENG 1
#define EASY 4
#define NOMAL 8
#define HARD 16

enum Zone
{
	Safe_Block = 10,
	Trap_Block = -1
};
struct Map_type
{
	bool open;
	int Block;
};
class Map
{
private:
	int m_iTrap_Num,m_iMap_leng;
	Map_type** m_ppMap;
	int* m_pTrap_Position;
	DrawManager m_Odraw;
public:
	void Print_Master_Map();
	void Print_Play_Map();

	void Map_Close(Position Position,int Num);
	void Map_Set(int Level);
	void Set_Trap_Position();
	void Install_Trap();
	void Set_init(int Level);
	int Confirm_Position(Position Position);
	int Search_Trap(Position Standard,Position Trop_Search,int Trap_Count);
	Map();
	~Map();
};

