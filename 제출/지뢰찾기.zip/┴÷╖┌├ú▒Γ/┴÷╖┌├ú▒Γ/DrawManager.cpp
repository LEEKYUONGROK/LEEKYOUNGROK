#include "DrawManager.h"

DrawManager::DrawManager()
{
}

void DrawManager::DrawMap(int Height,int Leng)
{
	Leng *= 2;
	for (int j = 0; j < Height; j++)
	{
		for (int i = 0;i < Leng;  i += 2)
		{
			gotoxy(i,j);
			cout << "��";
		}
	}
}
void DrawManager::DrawCuser(int x,int y,string str)
{
	gotoxy(x,y);
	cout << str;
}
DrawManager::~DrawManager()
{
}