#include "Map.h"

Map::Map()
{
	srand(time(NULL));
}

void Map::Set_init(int Level)
{
	system("cls");
	m_Odraw.DrawMap(Level, Level);
	m_iMap_leng = Level;
	m_iTrap_Num = Level;
	m_pTrap_Position = new int[m_iTrap_Num];

	Set_Trap_Position();
	Map_Set(m_iMap_leng);
}
void Map::Print_Master_Map()
{
	cout << endl;
	cout << endl;

	for (int i = 0; i < m_iMap_leng; i++)
	{
		for (int j = 0; j < m_iMap_leng; j++)
			if (m_ppMap[i][j].Block == Trap_Block)
				cout << "��";
			else
				cout << "��";
		cout << endl;
	}
}
void Map::Print_Play_Map()
{
	system("cls");
	for (int i = 0; i < m_iMap_leng; i++)
	{
		for (int j = 0; j < m_iMap_leng; j++)
			if (m_ppMap[i][j].open == false)
				cout <<" "<<m_ppMap[i][j].Block;
			else
				cout << "��";
		cout << endl;
	}
}
void Map::Map_Close(Position Select_Pos,int num)
{
	m_ppMap[Select_Pos.Y][Select_Pos.X].Block = num;
	m_ppMap[Select_Pos.Y][Select_Pos.X].open = false;
}
void Map::Install_Trap()
{
	int Trap_PositionX,Trap_PositionY;
	for (int i = 0; i < m_iTrap_Num; i++)
	{
		if ((float)m_pTrap_Position[i] / m_iMap_leng < 1)
			Trap_PositionY = 0;
		else
			Trap_PositionY = m_pTrap_Position[i] / m_iMap_leng;
		Trap_PositionX = m_pTrap_Position[i] % m_iMap_leng;
		m_ppMap[Trap_PositionY][Trap_PositionX].Block = Trap_Block;
	}
}

void Map::Set_Trap_Position()
{
	int Randem_num;
	bool b;
	for (int j = 0; j < m_iTrap_Num;)
	{
		b = false;
		Randem_num = rand() % (m_iMap_leng * m_iMap_leng);
		for (int i = 0; i < j; i++)
		{
			if (m_pTrap_Position[i] == Randem_num)
				b = true;
		}
		if (b == false)
		{
			m_pTrap_Position[j] = Randem_num;
			j++;
		}
	}
}

int Map::Search_Trap(Position Standard,Position Trop_Search,int Trap_Count)
{
	if (Trop_Search.X == Standard.X + 1 && Trop_Search.Y == Standard.Y + 1)
	{
		Trap_Count += Confirm_Position(Trop_Search);
		return Trap_Count;
	}
	else
	{
		Trap_Count += Confirm_Position(Trop_Search);
		if (Trop_Search.X < Standard.X + 1)
		{
			Trop_Search.X++;
			Search_Trap(Standard, Trop_Search, Trap_Count);
		}
		else
		{
			Trop_Search.X = Standard.X - 1;
			Trop_Search.Y++;
			Search_Trap(Standard, Trop_Search, Trap_Count);
		}
	}
}

int Map::Confirm_Position(Position Position)
{
	if ((Position.X >= 0 && Position.X < m_iMap_leng) &&
		(Position.Y >= 0 && Position.Y < m_iMap_leng))
	{
		if (m_ppMap[Position.Y][Position.X].Block == Trap_Block)
			return 1;
		else
			return 0;
	}
	else
		return 0;
}

void Map::Map_Set(int Level)
{
	m_ppMap = new Map_type*[Level];
	for (int i = 0; i < Level; i++)
		m_ppMap[i] = new Map_type[Level];
	for (int i = 0; i < Level; i++)
	{
		for (int j = 0; j < Level; j++)
		{
			m_ppMap[i][j].Block = Safe_Block;
		}
	}
	Install_Trap();
}

Map::~Map()
{
	delete[] *m_ppMap;
	delete m_ppMap;
	delete[] m_pTrap_Position;
}