#include "GameManager.h"

void main()
{
	GameManager Game;
	Game.Play();
}