#include "Player.h"

Player::Player()
{
	m_Player.X = 0;
	m_Player.Y = 0;
	m_iPlayer_LIFE = 1;
	m_sCusor = "��";
}
int Player::Life_Ckeck()
{
	if (m_iPlayer_LIFE <= 0)
		return 0;
	else
		return 1;
}
void Player::Move_Player(char key)
{
	switch (key)
	{
	case'A':
	case'a':
		if (m_Player.X > 0)
			m_Player.X -= 1 ;
		break;
	case'D':
	case'd':
		if (m_Player.X < m_iMap_Leng - 1)
			m_Player.X += 1;
		break;
	case'W':
	case'w':
		if (m_Player.Y > 0)
			m_Player.Y--;
		break;
	case'S':
	case's':
		if (m_Player.Y < m_iMap_Leng - 1)
			m_Player.Y++;
		break;
	}
	
	m_Draw.DrawCuser(m_Player.X * 2, m_Player.Y,m_sCusor);
}

Player::~Player()
{
}