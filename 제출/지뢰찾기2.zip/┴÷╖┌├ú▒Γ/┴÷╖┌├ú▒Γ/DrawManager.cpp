#include "DrawManager.h"

DrawManager::DrawManager()
{
}

DrawManager::~DrawManager()
{
}