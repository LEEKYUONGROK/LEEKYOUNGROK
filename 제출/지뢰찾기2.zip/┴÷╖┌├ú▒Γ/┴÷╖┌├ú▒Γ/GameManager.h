#pragma once
#include"Map.h"
#include"Player.h"

class GameManager
{
private:
	Player m_Player;
	Map m_Map;
	DrawManager Draw;
	int m_itime;
public:
	void Print_Menu();
	void Play();
	void Player_Postition_Confirm();
	GameManager();
	~GameManager();
};

