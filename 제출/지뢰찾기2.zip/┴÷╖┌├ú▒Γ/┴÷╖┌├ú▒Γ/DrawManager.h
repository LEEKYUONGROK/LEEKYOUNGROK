#pragma once
#include<iostream>
#include<Windows.h>
#include<conio.h>
#include<string>
#include<time.h>
using namespace std;

struct Position
{
	int X;
	int Y;
};
class DrawManager
{
private:
public:
	DrawManager();
	void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	~DrawManager();
};

