#include "Flag.h"
Flag::Flag()
{
	m_iflag_counter = 0;
}

void Flag::Print_Flag()
{
	for (int i = 0; i < m_iTrap_Num; i++)
	{
		if (m_Pflag[i].X != NULL && m_Pflag[i].Y != NULL)
		{
			m_Odraw.gotoxy(m_Pflag[i].X * 2, m_Pflag[i].Y);
			cout << "��";
		}
	}
}
void Flag::Set_List()
{
	m_Pflag = new Position[m_iTrap_Num];
	for (int i = 0; i < m_iTrap_Num; i++)
	{
		m_Pflag[i].X = NULL;
		m_Pflag[i].Y = NULL;
	}
}
bool Flag::Confirm_Game_END()
{
	int overlap_Flag_AND_Trap = 0;
	for (int i = 0; i < m_iTrap_Num; i++)
	{
		if (m_Pflag[i].X == NULL && m_Pflag[i].Y == NULL)
			break;
		else if (m_ppMap[m_Pflag[i].Y][m_Pflag[i].X].Block == Trap_Block)
			overlap_Flag_AND_Trap++;
	}
	if (overlap_Flag_AND_Trap == m_iTrap_Num)
		return true;
	else
		m_Odraw.gotoxy(0,m_iMap_leng);
		cout <<"ã�� ���ڼ� :"<<overlap_Flag_AND_Trap<<endl;
		cout << "�� ���ڼ� :" << m_iTrap_Num << " (������ �ش���ġ O,o��ư)";
		return false;
}
void Flag::insert_Flag_Position(Position position)
{
	if (m_iflag_counter == m_iTrap_Num)
		return;
	for (int i = 0; m_iTrap_Num > 0; i++)
	{
		if (m_Pflag[i].X == NULL && m_Pflag[i].Y == NULL)
		{
			m_Pflag[i].X = position.X;
			m_Pflag[i].Y = position.Y;
			m_iflag_counter++;
			return;
		}
	}
}
void Flag::overlap_Flag_Position(Position position)
{
	for (int i = 0; m_iTrap_Num > i; i++)
	{
		if (m_Pflag[i].X == position.X && m_Pflag[i].Y == position.Y)
		{
			m_Pflag[i].X = NULL;
			m_Pflag[i].Y = NULL;
			m_iflag_counter--;
			return;
		}	
	}
	insert_Flag_Position(position);
	return;
}
Flag::~Flag()
{
	delete[] m_Pflag;
}