#include "Map.h"

Map::Map()
{
	srand(time(NULL));
}

void Map::Set_init(int Level)
{
	system("cls");
	m_iMap_leng = Level;
	m_iTrap_Num = Level;
	m_iflag_counter = 0;
	m_pTrap_Position = new int[m_iTrap_Num];
	Set_Trap_Position();
	Map_Set(m_iMap_leng);

	Print_Play_Map();
	Print_Master_Map();
}
void Map::Print_Master_Map()
{
	for (int j = 0; j < m_iMap_leng; j++)
	{
		for (int i = 0; i < m_iMap_leng; i++)
		{
			m_Odraw.gotoxy(i * 2, (j + m_iMap_leng) + 2);
			if (m_ppMap[j][i].Block == Trap_Block)
				cout << "��";
			else
				cout << "��";
		}
	}
}
void Map::Print_Play_Map()
{
	for (int j = 0; j < m_iMap_leng; j++)
	{
		for (int i = 0; i < m_iMap_leng; i++)
		{
			m_Odraw.gotoxy(i * 2, j);
			if (m_ppMap[j][i].open == false)
				cout << " " << m_ppMap[j][i].Block;
			else
				cout << "��";
		}
	}
}
void Map::Position_Close(Position Select_Pos,int num)
{
	m_ppMap[Select_Pos.Y][Select_Pos.X].Block = num;
	m_ppMap[Select_Pos.Y][Select_Pos.X].open = false;
}
void Map::Install_Trap()
{
	int Trap_PositionX,Trap_PositionY;
	for (int i = 0; i < m_iTrap_Num; i++)
	{
		if ((float)m_pTrap_Position[i] / m_iMap_leng < 1)
			Trap_PositionY = 0;
		else
			Trap_PositionY = m_pTrap_Position[i] / m_iMap_leng;
		Trap_PositionX = m_pTrap_Position[i] % m_iMap_leng;
		m_ppMap[Trap_PositionY][Trap_PositionX].Block = Trap_Block;
	}
}

void Map::Set_Trap_Position()
{
	int Randem_num;
	bool b;
	for (int j = 0; j < m_iTrap_Num;)
	{
		b = false;
		Randem_num = rand() % (m_iMap_leng * m_iMap_leng);
		for (int i = 0; i < j; i++)
		{
			if (m_pTrap_Position[i] == Randem_num)
				b = true;
		}
		if (b == false)
		{
			m_pTrap_Position[j] = Randem_num;
			j++;
		}
	}
}
void Map::Search_sideline(int Standard_X,int Standard_Y)
{
	Position tmp;
	Position Search_tmp;
	for (int j = 0; j < 2; j++)
	{
		for (int i = 0; Standard_X + i >= 0 && Standard_X + i< m_iMap_leng;)
		{
			if (m_ppMap[Standard_Y][Standard_X + i].Block == Trap_Block)
				break;
			else
			{
				tmp.X = Standard_X + i;
				tmp.Y = Standard_Y;
				Search_tmp.X = Standard_X + i - 1;
				Search_tmp.Y = Standard_Y - 1;
				Position_Close(tmp, Search_Trap(tmp, Search_tmp, 0));
			}
			if (j == 0)
				i--;// ���� ��ǥ
			else
				i++;
		}
	}

}
void Map::Around_Search_Safe(Position Standard,int Search,int Y)
{
	if (Search >= m_iMap_leng - 1)
	{
		Search_sideline(Standard.X, Search);// y��ǥ�� X�� Ž��
		return;
	}
	else if	(Y > 0 &&(m_ppMap[Search][Standard.X].Block == Trap_Block 
		|| m_ppMap[Search][Standard.X].open == false))// ��������
		return;
	if (Search <= Standard.Y && Search >= 0 )//������Y���� ���ų� ���� Y�迭Ž�� 
	{
		if (Search == 0)
		{
			Search_sideline(Standard.X, Search);
			Y = 1;
			Search = Standard.Y + Y;
			Around_Search_Safe(Standard, Search, Y);
		}
		else if(m_ppMap[Search][Standard.X].Block == Trap_Block 
			|| m_ppMap[Search][Standard.X].open == false)
		{
			Y = 1;
			Search = Standard.Y + Y;
			Around_Search_Safe(Standard, Search, Y);
		}
		else
		{
			Search_sideline(Standard.X, Search);// y��ǥ�� X�� Ž��
			Y = -1;
			Search += Y;
			Around_Search_Safe(Standard, Search, Y);
		}
	}
	else//������Y���� ���� Y�迭Ž��
	{
		Search_sideline(Standard.X, Search);// y��ǥ�� X�� Ž��
		Search += Y;
		Around_Search_Safe(Standard, Search, Y);
	}
}

int Map::Search_Trap(Position Standard,Position Trop_Search,int Trap_Count)
{
	if (Trop_Search.X == Standard.X + 1 && Trop_Search.Y == Standard.Y + 1)
	{
		Trap_Count += Confirm_Position(Trop_Search);
		return Trap_Count;
	}
	else
	{
		Trap_Count += Confirm_Position(Trop_Search);
		if (Trop_Search.X < Standard.X + 1)
		{
			Trop_Search.X++;
			Search_Trap(Standard, Trop_Search, Trap_Count);
		}
		else
		{
			Trop_Search.X = Standard.X - 1;
			Trop_Search.Y++;
			Search_Trap(Standard, Trop_Search, Trap_Count);
		}
	}
}

int Map::Confirm_Position(Position Position)
{
	if ((Position.X >= 0 && Position.X < m_iMap_leng) &&
		(Position.Y >= 0 && Position.Y < m_iMap_leng))
	{
		if (m_ppMap[Position.Y][Position.X].Block == Trap_Block)
			return 1;
		else 
			return 0;
	}
	else
		return 0;
}
bool Map::If_Position_Open(Position position)
{
	if (m_ppMap[position.Y][position.X].open == false)
		return false;
	else
		return true;
}
void Map::Map_Set(int Level)
{
	m_ppMap = new Map_type*[Level];
	for (int i = 0; i < Level; i++)
		m_ppMap[i] = new Map_type[Level];
	for (int i = 0; i < Level; i++)
	{
		for (int j = 0; j < Level; j++)
			m_ppMap[i][j].Block = Safe_Block;
	}
	Install_Trap();
}

Map::~Map()
{
	delete[] *m_ppMap;
	delete m_ppMap;
	delete[] m_pTrap_Position;
}