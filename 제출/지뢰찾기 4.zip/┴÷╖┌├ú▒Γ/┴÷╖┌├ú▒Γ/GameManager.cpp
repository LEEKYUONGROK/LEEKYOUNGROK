#include "GameManager.h"

GameManager::GameManager()
{
	m_Map = &m_Flag ;
}
void GameManager::Print_Menu()
{
	int Select,Level;
	cout << "����ã�� ���̵��� �������ּ���(1.easy,2.nomal,3.hard) : ";
	cin >> Select;
	if (Select == 1)
		Level = EASY;
	else if (Select == 2)
		Level = NOMAL;
	else
		Level = HARD;
	m_Map->Set_init(Level);
	m_Map->Set_List();
	m_Player.input_MapLeng(Level);
}
void GameManager::Play()
{
	char key;
	Print_Menu();

	while (m_Player.Life_Ckeck())
	{
		key = _getch();
		if (key == 'k'|| key =='K')
			Player_Postition_Confirm();
		if (key == 'o' || key == 'O')
			Flag_Position_Confirm();
		else
			m_Player.Move_Player(key);
		m_Map->Print_Play_Map();
		m_Player.Print_Player();
		m_Map->Print_Flag();
	}
}
void GameManager::Player_Postition_Confirm()
{
	int counter = 0;
	Position P_position;
	P_position = m_Player.REturn_Player_Position();

	if (m_Map->If_Position_Open(P_position) == true)
	{
		if (m_Map->Confirm_Position(P_position) == 1)
		{
			m_Player.Life_Down();
			return;
		}
		m_Map->Around_Search_Safe(P_position, P_position.Y, 0);
	}
	else
		return;
}
void GameManager::Flag_Position_Confirm()
{
	Position P_position;
	P_position = m_Player.REturn_Player_Position();

	m_Map->overlap_Flag_Position(P_position);
	if (m_Map->Confirm_Game_END() == true)
		m_Player.Life_Down();
	return;
}
GameManager::~GameManager()
{
}
