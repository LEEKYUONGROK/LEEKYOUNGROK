#include "NameCard.h"


void Set_MemberList(Member_List* List)
{
	List->curcounter = -1;
	List->Numcounter = 0;
}

bool Member_List_First(Member_List* List)
{
	if (List->Numcounter <= 0)
		return false;
	List->curcounter = 0;
		return true;
}
bool Member_List_Next(Member_List* List)
{
	if (List->curcounter < List->Numcounter - 1)
	{
		List->curcounter++;
		return true;
	}
	else
		return false;
}
void RemoveNameCard(Member_List* List)
{
	int Now_Pos = List->curcounter;
	int L_Num = List->Numcounter - 1;

	for (int i = Now_Pos; i <= L_Num - 1; i++)
		List->P_NameCard[i] = List->P_NameCard[i + 1];

	List->curcounter--;
	List->Numcounter--;
}
void Mem_List_Input_Inpo(Member_List* List, NameCard Inpo)
{
	if (List->Numcounter >= MEMBER_MAX)
		return;
	List->P_NameCard[List->Numcounter] = MakeNameCard(Inpo.name, Inpo.phone);
	List->Numcounter++;
}

void ChangePhoneNum(NameCard* pcard, char * phone)
{
	for (int i = 0; i < NAME_LEN; i++)
		pcard->phone[i] = phone[i];
}
void ShowNameCardInfo(NameCard* pcard)
{
	cout << "�̸� : " << pcard->name << " ��ȭ��ȣ : " << pcard->phone << endl;
}

bool NameCompare(NameCard* pcard, char * name)
{
	int i;
	for (i = 0;name[i] != NULL; i++)
	{
		if (pcard->name[i] == NULL || pcard->name[i] != name[i])
			return false;
	}
	if(pcard->name[i] != NULL)
		return false;
	else
		return true;
}
NameCard* MakeNameCard(char* name, char * phone)
{
	NameCard* P_NameCard;
	P_NameCard = new NameCard;
	
	for (int i = 0; i < NAME_LEN; i++)
	{
		P_NameCard->name[i] = name[i];
		P_NameCard->phone[i] = phone[i];
	}
	return P_NameCard;
}
