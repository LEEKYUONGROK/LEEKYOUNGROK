#include "ArrayList.h"
#include "NameCard.h"

void Test1();
void Test2_Input_Member_inpo(Member_List* Member_List);
void Test2_Select_Name(Member_List* Member_List);

void main()
{
	Member_List Member_List;
	NameCard NameCard_tmp;
	int m_iSelect;
	Test1();

	Set_MemberList(&Member_List);
	Test2_Input_Member_inpo(&Member_List);

	//	Test2_Select_Name(&Member_List);
	system("cls");
	cout << "ã���ô� ����� �̸��� �Է��ϼ��� : ";
	cin >> NameCard_tmp.name;
	if (Member_List_First(&Member_List))
	{
		if (NameCompare(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.name))
			ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);
		while (Member_List_Next(&Member_List))
		{
			if (NameCompare(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.name))
				ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);
		}
	}

	cout << endl <<"ã���ô� ����� �̸��� �Է��ϼ��� : ";
	cin >> NameCard_tmp.name;
	if (Member_List_First(&Member_List))
	{
		if (NameCompare(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.name))
		{
			cout << "������ ��ȭ��ȣ�� �Է����ּ��� :";
			cin >> NameCard_tmp.phone;
			ChangePhoneNum(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.phone);
			ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);
			cout << "����Ϸ�";
		}
		while (Member_List_Next(&Member_List))
		{
			if (NameCompare(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.name))
			{
				cout << "������ ��ȭ��ȣ�� �Է����ּ��� :";
				cin >> NameCard_tmp.phone;
				ChangePhoneNum(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.phone);
				ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);
				cout << "����Ϸ�";
			}
		}
	}

	cout << endl <<"ã���ô� ����� �̸��� �Է��ϼ��� : ";
	cin >> NameCard_tmp.name;
	system("cls");
	if (Member_List_First(&Member_List))
	{
		if (NameCompare(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.name))
		{
			ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);
			cout << endl << "���� �Ͻðڽ��ϱ�? yes1,no2 : ";
			cin >> m_iSelect;
			if (m_iSelect == 1)
			{
				RemoveNameCard(&Member_List);
				cout << "����Ϸ�";
			}
		}
		while (Member_List_Next(&Member_List))
		{
			if (NameCompare(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.name))
			{
				ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);
				cout << endl << "���� �Ͻðڽ��ϱ�? yes1,no2 : ";
				cin >> m_iSelect;
				if (m_iSelect == 1)
				{
					RemoveNameCard(&Member_List);
					cout << "����Ϸ�";
				}
			}
		}
	}

	cout << endl;
	if (Member_List_First(&Member_List))
	{
		ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);
		while (Member_List_Next(&Member_List))
			ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);

	}
}


void Test1()
{
	List Main_LIST;
	LData tmp, sum = 0;
	ListInit(&Main_LIST);

	for (int i = 1; i < 10; i++)
		Linsert(&Main_LIST, i);

	if (LFirst(&Main_LIST, &tmp))
	{
		sum = tmp;
		while (LNext(&Main_LIST, &tmp))
			sum += tmp;
		cout << "�� : " << sum << endl;
	}
	if (LFirst(&Main_LIST, &tmp))
	{
		if (Main_LIST.arr[Main_LIST.curPosition] % 2 == 0 ||
			Main_LIST.arr[Main_LIST.curPosition] % 3 == 0)
			cout << "����(" << LRemove(&Main_LIST) << ") ����" << endl;
		while (LNext(&Main_LIST, &tmp))
			if (Main_LIST.arr[Main_LIST.curPosition] % 2 == 0 ||
				Main_LIST.arr[Main_LIST.curPosition] % 3 == 0)
				cout << "����(" << LRemove(&Main_LIST) << ") ����" << endl;
	}
	if (LFirst(&Main_LIST, &tmp))
	{
		cout << "������ ���� :" << tmp << endl;
		while (LNext(&Main_LIST, &tmp))
			cout << "������ ���� :" << tmp << endl;
	}

}

void Test2_Input_Member_inpo(Member_List* Member_List)
{
	NameCard NameCard_tmp;
	for (int i = 0; i < MEMBER_MAX; i++)
	{
		cout << "�̸��� �Է� ���ּ��� : ";
		cin >> NameCard_tmp.name;
		cout << "����ȣ �Է� ���ּ��� : ";
		cin >> NameCard_tmp.phone;
		Mem_List_Input_Inpo(Member_List, NameCard_tmp);
		cout << endl;
	}
}

/*void Test2_Select_Name(Member_List* Member_List)
{
	NameCard NameCard_tmp;
	cout << "ã���ô� ����� �̸��� �Է��ϼ��� : ";
	cin >> NameCard_tmp.name;

	if (Member_List_First(Member_List))
	{
		if (NameCompare(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.name))
			ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);
		while (Member_List_Next(&Member_List))
		{
			if (NameCompare(Member_List.P_NameCard[Member_List.curcounter], NameCard_tmp.name))
				ShowNameCardInfo(Member_List.P_NameCard[Member_List.curcounter]);
		}
	}
}
*/