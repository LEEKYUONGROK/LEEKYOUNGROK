#include "Item.h"

Item::Item()
{
}

int Item::Input_Word(string str,Player_inpomation* P_Object)
{
	m_Pplayer = P_Object;
	tmp = Head;
	if (tmp->Sword == "")
		tmp = tmp->Next;
	while (tmp != NULL)
	{
		if ((tmp->Sword == str) && (str != ""))
		{
			tmp->Sword = "";
			tmp->Position_X = 0;
			tmp->Position_Y = 0;
			return Using_Item(tmp->Color,P_Object);
		}
		else
			tmp = tmp->Next;
	}
	P_Object->operator--;
	return -1;
}
int Item::Using_Item(int Color, Player_inpomation* Object)
{
	if (Color == COL_BLUE)
	{
		Object->Point_UP();
		return COL_BLUE;
	}
	else if (Color == COL_YELLOW)
	{
		Delete_List(Head);
		Set_Head();
	}
	else if (Color == COL_RED)
		Object->operator++;
	Object->Point_UP();
	return 0;
}

Item::~Item()
{
}
