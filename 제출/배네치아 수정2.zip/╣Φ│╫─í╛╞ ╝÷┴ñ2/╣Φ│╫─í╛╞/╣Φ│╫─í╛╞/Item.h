#pragma once
#include "Word.h"

class Item : public Word
{
public:
	Player_inpomation* m_Pplayer;
	int Using_Item(int Color, Player_inpomation* P_Object);
	int Input_Word(string st, Player_inpomation* P_Object);
	Item();
	~Item();
};

