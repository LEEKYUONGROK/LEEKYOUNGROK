#pragma once
#include "Item.h"

class GameManager
{
private:
	int Move_Clock, Produce_Clock, CurClock, m_iStage, m_iGame_Speed;
string input_string;
DrawManager m_Odraw;
Player_inpomation m_Oplayer;

public:
	string input_Back(string text);
	bool Menu();
	void Play();
	GameManager();
	~GameManager();
};

