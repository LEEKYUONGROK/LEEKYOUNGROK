#include "Player_inpomation.h"



Player_inpomation::Player_inpomation()
{
	Counter = 0;
}
bool Player_inpomation::Player_GameOver()
{
	if (Counter < 5 && Player_List[Counter].m_iPlayerLife <= 0)
	{
		Counter++;
		return true;
	}
	else
		return false;
}
void Player_inpomation::Print_Player_Rank()
{
	Player_inpo tmp;
	system("cls");
	if (Counter == 0)
		cout << "����� �÷��̾ �����ϴ�";
	else if (Counter == 1)
	{
		cout << Player_List[Counter - 1].Name << endl;
		cout << Player_List[Counter - 1].Point << endl;
	}
	else
	{
		for (int i = 0; i < Counter; i++)
		{
			for(int j = 0;j < Counter ;j++)
			if (Player_List[i].Point > Player_List[j].Point)
			{
				tmp = Player_List[i];
				Player_List[i] = Player_List[j];
				Player_List[j] = tmp;
			}
		}
		for (int i = 0; i < Counter; i++)
		{
			cout << i+1 << "���� �÷��̾�";
			cout << Player_List[i].Name << endl;
			cout << Player_List[i].Point << endl;
			cout << endl;
		}
	}
	system("pause");
}
void Player_inpomation::Set_Player()
{
	system("cls");
	Draw.Mid_print("�̸��� �Է����ּ��� : ", 15);
	cin >> Player_List[Counter].Name;
	Player_List[Counter].Point = 0;
	Player_List[Counter].m_iPlayerLife = 5;
}
void Player_inpomation::Point_UP()
{
	Player_List[Counter].Point += 100;
}
void Player_inpomation::Print_Inpomatoin()
{
	Draw.Print_PointLife(Player_List[Counter].Point, Player_List[Counter].m_iPlayerLife);
}
bool Player_inpomation::Return_NowLife()
{
	if (Player_List[Counter].m_iPlayerLife <= 0)
		return false;
	else 
		return true;
}
Player_inpomation::~Player_inpomation()
{
}
