#include "DLinkedList.h"

void ListInit(List * plist)
{
	plist->head = NULL;
	plist->tail = NULL;
	plist->before = NULL;
	plist->comp = NULL;
	plist->numOfData = 0;

	Set_Tail_Dummy(plist);
	Set_Head_Dummy(plist);
}
void Set_Tail_Dummy(List* plist)
{
	plist->tail = (Node*)malloc(sizeof(Node));
	plist->tail->next = NULL;
}
void Set_Head_Dummy(List* plist)
{
	plist->head = (Node*)malloc(sizeof(Node));
	plist->head->next = plist->tail;
}

void New_Node_ToHead(List * plist, LData data)
{
	Node * newNode = (Node*)malloc(sizeof(Node));
	newNode->data = data;
	newNode->next = plist->head->next;

	plist->head->next = newNode;
	(plist->numOfData)++;
}

void New_Node_ToTail(List * plist, LData data)
{
	Node* New_Node = (Node*)malloc(sizeof(Node));
	New_Node->next = NULL;
	
	plist->tail->data = data;
	plist->tail->next = New_Node;
	plist->tail = New_Node;
	(plist->numOfData)++;
}
void SInsert(List * plist, LData data)
{
	//�������� �ʴ� ����Ʈ���� �ʿ�x FInsert�� ���� �ൿ���Ѵ�
	Node * newNode = (Node*)malloc(sizeof(Node));
	Node * pred = plist->head;
	newNode->data = data;

	/*while (pred->next != NULL &&
		plist->comp(data, pred->next->data) != 0)
	{
		pred = pred->next;
	}*/
	newNode->next = pred->next;
	pred->next = newNode;

	(plist->numOfData)++;
}


void LInsert(List * plist, LData data)
{

}

int LFirst(List * plist, LData * pdata)
{
	if (plist->head->next == plist->tail)// ������ ���� ����
		return FALSE;

	plist->before = plist->head;
	plist->cur = plist->head->next;

	*pdata = plist->cur->data;
	return TRUE;
}

int LNext(List * plist, LData * pdata)
{
	if (plist->cur->next == plist->tail)
		return FALSE;

	plist->before = plist->cur;
	plist->cur = plist->cur->next;

	*pdata = plist->cur->data;
	return TRUE;
}

LData LRemove(List * plist)
{
	Node * rpos = plist->cur;
	LData rdata = rpos->data;

	plist->before->next = plist->cur->next;
	plist->cur = plist->before;

	free(rpos);
	(plist->numOfData)--;
	return rdata;
}
void List_Remove(List* plist)
{
	Node* next_add;
	plist->cur = plist->head;

	while (1)
	{
		if (plist->cur->next == plist->tail)
		{
			free(plist->cur);
			free(plist->tail);
			return;
		}
		else
		{
			next_add = plist->cur->next;
			free(plist->cur);
			plist->cur = next_add;
		}
	}
}
int LCount(List * plist)
{
	return plist->numOfData;
}

void SetSortRule(List * plist, int(*comp)(LData d1, LData d2))
{

}