#pragma once
#include "DrawManager.h"
#include "Player_inpomation.h"
#include <fstream>
#include <time.h>
#include <conio.h>
#define LIST_MAX 10


struct  Word_inpomation
{
	string Sword;
	int Position_X, Position_Y, Color;
	Word_inpomation* Next;
};

class Word
{
protected:
	string* Word_List;
	Word_inpomation* Head = NULL, *tmp, *add_Word, *Null_Next_Adress, *Delete_Adress;
	int List_Counter, m_iWhile_Counter;
	DrawManager Draw;
public:
	virtual void Set_NewWord_AND_Col() = 0;
	virtual void Set_Head_Col() = 0;
	virtual void Yellow_Item() = 0;
	virtual void Plum_Item() = 0;
	virtual int Input_Word(string st) = 0;
	virtual void Set_Color(Word_inpomation* Word_inpo) = 0;

	void Move_Word();
	void Print_List();
	int Over_PositionCheck();

	void If_Next_WordNull();
	void Delete_List(Word_inpomation* Node);
	void If_Next_Adress_Null();
	void Delete_Null_Adress();
	void Set_List(int Level);
	void Set_Head();
	void Set_NewWord();
	Word();
	~Word();
};