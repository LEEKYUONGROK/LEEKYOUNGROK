#include "Word.h"



Word::Word()
{
	Delete_Adress = NULL;
	Null_Next_Adress = NULL;
	Word_List = new string[LIST_MAX];
	List_Counter = 0;
	for (int i = 0; i < LIST_MAX; i++)
		Word_List[i] = "";
}
void Word::Set_List(int Level)
{
	int count = 0;
	string Load_File = "Level";
	Load_File += to_string(Level);
	Load_File += ".txt";

	ifstream load;
	load.open(Load_File);
	while (!load.eof())
	{
		load >> Word_List[count];
		count++;
	}
}
void Word::Set_Head()
{
	srand(time(NULL));
	Head = new Word_inpomation;
	Head->Position_X = (rand() % 68) + 2;
	Head->Position_Y = 0;
	Head->Sword = Word_List[rand() % LIST_MAX];
	Head->Next = NULL;
	List_Counter++;
}
void Word::Delete_List(Word_inpomation* Node)
{
	if (Node == NULL)
		return;
	Delete_List(Node->Next);
	delete Node;
}
void Word::Move_Word()
{ 
	tmp = Head;
	while (tmp != NULL)
	{
		if (tmp->Sword == "")
		{
			tmp = tmp->Next;
			continue;
		}
		tmp->Position_Y++;
		tmp = tmp->Next;
	}
}
void Word::Set_NewWord()
{
	tmp = Head;
	while (tmp->Next !=NULL)
	{
		tmp = tmp->Next;
	}
	add_Word = new Word_inpomation;
	add_Word->Position_X = (rand() % 68) + 2;
	add_Word->Position_Y = 0;
	add_Word->Sword = Word_List[rand() % LIST_MAX];
	add_Word->Next = NULL;
	tmp->Next = add_Word;
}
int Word::Over_PositionCheck()
{
	int Over_counter = 0;
	tmp = Head;
	if (tmp->Sword == "")
		tmp = tmp->Next;
	while (tmp != NULL)
	{
		if (tmp->Position_Y >= HIEGHT)
		{
			Over_counter += 1;
			tmp->Sword = "";
			tmp->Position_X = 0;
			tmp->Position_Y = 0;
		}
		tmp = tmp->Next;
	}
	return Over_counter;
}
int Word::Input_Word(string str)
{
	tmp = Head;
	if (tmp->Sword == "")
		tmp = tmp->Next;
	while (tmp != NULL)
	{
		if ((tmp->Sword == str) && (str != ""))
		{
			tmp->Sword = "";
			tmp->Position_X = 0;
			tmp->Position_Y = 0;
			return tmp->Color;
		}
		else
			tmp = tmp->Next;
	}
	return -1;
}
void Word::If_Next_Adress_Null()
{
	tmp = Head;
	while (tmp != NULL)
	{
		if (tmp->Next == NULL && tmp != add_Word)
		{
			tmp->Next = Null_Next_Adress;
			break;
		}
		else
			tmp = tmp->Next;
	}
}
void Word::If_Next_WordNull()
{
	tmp = Head;
	while ((tmp != NULL) && (tmp != add_Word))
	{
		if (tmp->Next == NULL)
		{
			tmp->Next = Null_Next_Adress;
			delete Delete_Adress;
			break;
		}
		else
			tmp = tmp->Next;
	}
}
void Word::Delete_Null_Adress()
{
	tmp = Head;
	while (tmp != NULL)
	{
		if ((tmp->Sword == "") && (tmp->Position_X == 0 && tmp->Position_Y == 0))
		{
			Null_Next_Adress = tmp->Next; 
			Delete_Adress = tmp;
			tmp = NULL;
			break;
		}
		else
			tmp = tmp->Next;
	}
}
void Word::Print_List()
{
	tmp = Head;
	while (tmp != NULL)
	{
		Draw.Draw_String(tmp->Sword, tmp->Position_X, tmp->Position_Y, tmp->Color);
		tmp = tmp->Next;
	}
}
Word::~Word()
{
	Delete_List(Head);
	delete[] Word_List;
}
