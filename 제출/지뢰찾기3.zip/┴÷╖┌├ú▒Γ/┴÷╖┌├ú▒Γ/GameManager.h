#pragma once
#include"Map.h"
#include"Player.h"
#include"Flag.h"
class GameManager
{
private:
	Flag m_Flag;
	Player m_Player;
	Map* m_Map;
	DrawManager Draw;
	int m_itime;
public:
	void Print_Menu();
	void Play();
	void Flag_Position_Confirm();
	void Player_Postition_Confirm();
	GameManager();
	~GameManager();
};

