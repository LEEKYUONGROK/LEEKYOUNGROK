#pragma once
#include "Map.h"
#define NULL -1

class Flag : public Map
{
private:
	DrawManager Draw;
	int m_iflag_counter;
	Position* m_Pflag;
public:
	void Print_Flag();
	void Set_List();
	void insert_Flag_Position(Position position);
	void overlap_Flag_Position(Position position);
	bool Confirm_Game_END();
	Flag();
	~Flag();
};

