#pragma once
#include"DrawManager.h"

class Player
{

private:
	DrawManager m_Draw;
	Position m_Player;
	string m_sCusor;
	int m_iMap_Leng, m_iPlayer_LIFE;
public:
	void Print_Player();
	void Move_Player(char key);
	inline void input_MapLeng(int leng){ m_iMap_Leng = leng;}
	inline Position REturn_Player_Position() { return m_Player ;}
	inline void Life_Down() { m_iPlayer_LIFE--; }
	int Life_Ckeck();
	Player();
	~Player();
};

