#pragma once
#include "DrawManager.h"
#define EASY 4
#define NOMAL 8
#define HARD 16

enum Zone
{
	Safe_Block = 10,
	Trap_Block = -1
};
struct Map_type
{
	bool open;
	int Block;
};
class Map
{
protected:
	int m_iTrap_Num,m_iMap_leng,m_iflag_counter;
	Map_type** m_ppMap;
	int* m_pTrap_Position;
	DrawManager m_Odraw;
public:
	void Print_Master_Map();
	void Print_Play_Map();

	void Around_Search_Safe(Position Standard, int Search, int Y);
	void Search_sideline(int Standard_X,int Standard_Y);
	int Confirm_Position(Position Position);
	int Search_Trap(Position Standard, Position Trop_Search, int Trap_Count);

	bool If_Position_Open(Position position);
	void Position_Close(Position Position,int Num);
	void Map_Set(int Level);
	void Set_Trap_Position();
	void Install_Trap();
	void Set_init(int Level);

	virtual void Print_Flag() = 0;
	virtual void Set_List() = 0;
	virtual void insert_Flag_Position(Position position) = 0;
	virtual void overlap_Flag_Position(Position position) = 0;
	virtual bool Confirm_Game_END() = 0;
	Map();
	~Map();
};

